//
//  LTAppDelegate.m
//  Latte
//
//  Created by Alex Usbergo on 6/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LTAppDelegate.h"
#import "LTMenu.h"

@implementation LTAppDelegate

@synthesize window = _window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application

}

@end
