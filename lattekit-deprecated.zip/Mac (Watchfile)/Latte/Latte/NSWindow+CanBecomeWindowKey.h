//
//  NSWindow+CanBecomeWindowKey.h
//  Latte
//
//  Created by Alex Usbergo on 7/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSWindow (CanBecomeWindowKey)

@end
