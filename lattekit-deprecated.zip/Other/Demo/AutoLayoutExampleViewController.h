//
//  AutoLayoutExampleViewController.h
//  Latte
//
//  Created by Alex Drone Usbergo on 23/09/12.
//
//

#import <UIKit/UIKit.h>

@interface AutoLayoutExampleViewController : UIViewController

@end
