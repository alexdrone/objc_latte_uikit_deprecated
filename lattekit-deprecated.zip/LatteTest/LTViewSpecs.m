#import "TestData.h"

SPEC_BEGIN(LTViewSpecs)

describe(@"LTView is well constructed from a valid json markup", ^{
	
		
});







SPEC_END