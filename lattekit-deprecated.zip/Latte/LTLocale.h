//
//  LTLocale.h
//  Latte
//
//  Created by Alex Usbergo on 7/14/12.
//
//

#import <Foundation/Foundation.h>

@interface LTLocale : NSObject

+ (LTLocale*)sharedInstance;


@end
